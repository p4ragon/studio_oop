import java.time.LocalDate;

?? ProdottoNonAlimentare ??{
  /* completare con eventuali attributi */


    public ProdottoNonAlimentare(String codice, String descrizione, double prezzo,String materiale) {
        /* completare */
            
    }

public boolean isRiciclabile() {
       
       /*completare*/
   }   
   /* completare implementando altri metodi se necessario */

    @Override
    public String toString() {
        /*completare */
    }
    
    
    
    
}
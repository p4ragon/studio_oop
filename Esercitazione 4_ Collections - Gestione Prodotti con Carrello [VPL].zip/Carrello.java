
import ??

/**
 *
 * @author leonardorundo
 */
?? Carrello ?? {
    
    /* completare con eventuali attributi */
    
    public Carrello(){
        /*completare */    
    }
    
    public void addProdotto(Prodotto p){
        /*completare */
        
    }
    
    public double getTotale(){
        /*completare */    
        
    }
    
    public double getTotaleScontato(){
        /*completare */    
        
    }

    
    public void removeProdotto(Prodotto p){
        /*completare */
        
    }
    
    public Prodotto getProdotto(int idx){
        /*completare */
        
    }
    
    
    @Override
    public String toString(){
        /*completare */
        
    }
    
    
    
}

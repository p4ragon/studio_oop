import java.time.LocalDate;

/**
 *
 */
?? ProdottoAlimentare ?? {
    ?? LocalDate dataScadenza;

    public ProdottoAlimentare(String codice, String descrizione, double prezzo, LocalDate dataScadenza) {

     /*completare */


    }

   /* completare implementando ulteriori metodi se necessario */

    public LocalDate getDataScadenza() {
        return dataScadenza;
    }

    @Override
    public String toString() {
        /* completare */
    }
    
    
    
    
    
}
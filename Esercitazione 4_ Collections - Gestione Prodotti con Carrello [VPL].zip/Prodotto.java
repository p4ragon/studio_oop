import java.time.LocalDate;

?? Prodotto {
    ?? String codice;
    ?? String descrizione;
    ?? double prezzo;

    public Prodotto(String codice, String descrizione, double prezzo) {
      /* completare */


    }

    /* completare includendo getter per tutti gli attributi */

/* completare prevedendo il metodo applicaSconto() */   
 




    @Override
    public String toString() {
        return "\nProdotto:\n" + "codice=" + codice + "\ndescrizione=" + descrizione + "\nprezzo=" + prezzo ;
    }
    
    
}